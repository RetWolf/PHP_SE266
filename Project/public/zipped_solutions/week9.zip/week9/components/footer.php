<footer class="fixed-bottom text-center">
  <p>SE 266 Final Exam Fall 2018 - Matt Conway</p>
</footer>